package appmoviles.com.semana9appmoviles;

import android.view.View;

public class MainController implements Stopwatch.OnValueListener, View.OnClickListener, GetRequest.OnResponseListener {

    private MainActivity view;
    private Stopwatch stopwatch;

    public MainController(MainActivity view){
        this.view = view;
        stopwatch = new Stopwatch();
        stopwatch.setListener(this);
        stopwatch.start();

        view.getGetBtn().setOnClickListener(this);
    }

    @Override
    public void onValue(int time) {
        //Poner el valor del cronometro en un Textview
        view.runOnUiThread(
                () -> {
                    view.getStopwatchTV().setText(""+time);
                }
        );

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.getBtn:
                String url = this.view.getUrlET().getText().toString();
                GetRequest request = new GetRequest(url);
                request.setListener(this);
                request.start();
                break;
        }
    }

    @Override
    public void onResponse(String response) {
        //Recibimos los bytes que nos descargamos y los cargamos en el textview
        view.runOnUiThread(
                ()->{
                    view.getResponseTV().setText(response);
                }
        );
    }
}
