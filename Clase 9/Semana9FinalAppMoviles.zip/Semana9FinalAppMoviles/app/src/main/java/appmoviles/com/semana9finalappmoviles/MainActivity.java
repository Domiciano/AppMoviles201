package appmoviles.com.semana9finalappmoviles;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private MainController controller;
    private ImageView photoIV;
    private Button cameraButton;
    private Button galleryButton;
    private Button downloadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        photoIV = findViewById(R.id.photoIV);
        cameraButton = findViewById(R.id.cameraButton);
        galleryButton = findViewById(R.id.galleryButotn);
        downloadButton = findViewById(R.id.downloadButton);

        controller = new MainController(this);
    }

    //Control+O


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        controller.onActivityResult(requestCode, resultCode, data);
    }

    public ImageView getPhotoIV() {
        return photoIV;
    }

    public Button getCameraButton() {
        return cameraButton;
    }

    public Button getGalleryButton() {
        return galleryButton;
    }

    public Button getDownloadButton() {
        return downloadButton;
    }
}
