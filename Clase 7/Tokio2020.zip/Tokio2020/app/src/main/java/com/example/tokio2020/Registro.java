package com.example.tokio2020;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

public class Registro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        Toolbar registroToolbar =
                (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(registroToolbar);

        // Asignación del soporte de ActionBar al Toolbar personalizado
        ActionBar ab = getSupportActionBar();
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        // Activación del botón regresar
        ab.setDisplayHomeAsUpEnabled(true);

    }
}
