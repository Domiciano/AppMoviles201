package com.example.tokio2020;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Inicio extends AppCompatActivity {

    Button btn_registrarse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.AppTheme);
        setContentView(R.layout.activity_inicio);

        //Inicialización del botón Regístrate
        btn_registrarse = (Button) findViewById(R.id.button_registrate);
        btn_registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRegistro();
            }
        });

        SpannableString texto = new SpannableString("¿No tienes cuenta? Regístrate");
        //Texto en color gris
        texto.setSpan(new ForegroundColorSpan (getResources().getColor(R.color.textos)), 0, 18, 0);
        //Texto en color primary
        texto.setSpan(new ForegroundColorSpan (getResources().getColor(R.color.colorPrimary)), 19, 29, 0);
        //Texto con estilo "Bold"
        texto.setSpan(new StyleSpan(Typeface.BOLD), 19, 29, 0);
        btn_registrarse.setText(texto, TextView.BufferType.SPANNABLE);
    }

        //Método para iniciar la actividad Registro
        public void openRegistro() {
            Intent intent = new Intent(this, Registro.class);
            startActivity(intent);
        }
    }

