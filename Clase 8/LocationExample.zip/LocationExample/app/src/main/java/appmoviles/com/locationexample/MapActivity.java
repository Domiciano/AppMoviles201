package appmoviles.com.locationexample;

import androidx.fragment.app.FragmentActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.maps.android.PolyUtil;

import org.w3c.dom.Text;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback, LocationListener {

    private GoogleMap mMap;
    private Marker me;
    private TextView output;
    private Polygon icesi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        output = findViewById(R.id.output);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LocationManager manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500, 2, this);

        //LatLng pos = new LatLng(3, -76);
        Location last = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        LatLng pos = new LatLng(last.getLatitude(), last.getLongitude());

        me = mMap.addMarker(  new MarkerOptions().position(pos).title("Yo").snippet("Mi ubicación")  );

        icesi = mMap.addPolygon(
                new PolygonOptions()
                        .add(new LatLng(3.342988,-76.530896))
                        .add(new LatLng(3.343256,-76.529136))
                        .add(new LatLng(3.339946,-76.528385))
                        .add(new LatLng(3.339796,-76.531304))
                        .fillColor( Color.argb(50, 255,0,0) )
                        .strokeColor( Color.argb(50, 255,0,0) )
        );


    }

    @Override
    public void onLocationChanged(Location location) {
        LatLng pos = new LatLng(location.getLatitude(), location.getLongitude());
        me.setPosition(  pos  );
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(pos, 17));
        output.setText("Accuracy: "+location.getAccuracy());

        if(PolyUtil.containsLocation(pos, icesi.getPoints(), true)){
            output.append("\nEstá en Icesi");
        }
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {}

    @Override
    public void onProviderEnabled(String s) {}

    @Override
    public void onProviderDisabled(String s) {}
}
