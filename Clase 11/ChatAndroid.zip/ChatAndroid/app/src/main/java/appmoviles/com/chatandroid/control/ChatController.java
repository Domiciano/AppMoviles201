package appmoviles.com.chatandroid.control;

import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import appmoviles.com.chatandroid.R;
import appmoviles.com.chatandroid.model.Message;
import appmoviles.com.chatandroid.model.User;
import appmoviles.com.chatandroid.view.ChatActivity;

public class ChatController implements View.OnClickListener{

    private ChatActivity activity;

    private String username;
    private String chatroom;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> data;
    private User user;

    public ChatController(final ChatActivity activity) {
        this.activity = activity;

        data = new ArrayList<>();
        adapter = new ArrayAdapter<String>(activity, android.R.layout.simple_list_item_1, data);
        activity.getMessagesList().setAdapter(adapter);


        username = activity.getIntent().getExtras().getString("username");
        chatroom = activity.getIntent().getExtras().getString("chatroom");

        activity.getSendBtn().setOnClickListener(this);



        Query queryBusqueda = FirebaseDatabase.getInstance().getReference()
                .child("user").orderByChild("username").equalTo(username);


        queryBusqueda.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot coincidencia : dataSnapshot.getChildren() ){
                    user = coincidencia.getValue(User.class);
                    activity.getUsernameTV().setText(user.getUsername());
                    break;
                }
                Log.e(">>>BUSQUEDA", user.getId()+":"+user.getUsername());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        //Si es una lista
        Query query = FirebaseDatabase.getInstance()
                .getReference()
                .child("chats").child(chatroom);
        query.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Message message = dataSnapshot.getValue(Message.class);
                data.add(message.getBody());
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        //Si es una lista

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.sendBtn:
                String body = activity.getMessageET().getText().toString();

                String pushId = FirebaseDatabase.getInstance().getReference()
                        .child("chats").child(chatroom).push().getKey();

                Message message = new Message(
                        pushId,
                        body,
                        user.getId(),
                        Calendar.getInstance().getTime().getTime());

                FirebaseDatabase.getInstance().getReference()
                        .child("chats").child(chatroom).child(pushId).setValue(message);

                break;
        }
    }
}
