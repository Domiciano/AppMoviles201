package appmoviles.com.chatandroid.control;

import android.content.Intent;
import android.view.View;

import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

import appmoviles.com.chatandroid.R;
import appmoviles.com.chatandroid.model.User;
import appmoviles.com.chatandroid.view.ChatActivity;
import appmoviles.com.chatandroid.view.MainActivity;

public class MainController implements View.OnClickListener{

    private MainActivity activity;

    public MainController(MainActivity activity) {
        this.activity = activity;

        activity.getSigninBtn().setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.signinBtn:
                String chatroom = activity.getChatroomET().getText().toString();
                String username = activity.getUsernameET().getText().toString();

                String pushid = FirebaseDatabase.getInstance().getReference().child("user").push().getKey();


                User user = new User(pushid, username);

                FirebaseDatabase.getInstance().getReference().child("user").child(pushid).setValue(user);

                Intent intent = new Intent(activity, ChatActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("chatroom", chatroom);
                activity.startActivity(intent);
                activity.finish();

                break;
        }
    }
}
