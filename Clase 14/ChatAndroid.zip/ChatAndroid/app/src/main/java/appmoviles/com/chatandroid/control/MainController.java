package appmoviles.com.chatandroid.control;

import android.Manifest;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;
import java.util.UUID;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.Observer;
import appmoviles.com.chatandroid.R;
import appmoviles.com.chatandroid.db.MessagesRepository;
import appmoviles.com.chatandroid.model.Message;
import appmoviles.com.chatandroid.model.User;
import appmoviles.com.chatandroid.view.ChatActivity;
import appmoviles.com.chatandroid.view.MainActivity;
import appmoviles.com.chatandroid.view.SignupActivity;

public class MainController implements View.OnClickListener{

    private MainActivity activity;

    public MainController(MainActivity activity) {
        this.activity = activity;

        activity.getSigninBtn().setOnClickListener(this);
        activity.getSignupTV().setOnClickListener(this);
        activity.getContinueAsBtn().setOnClickListener(this);

        ActivityCompat.requestPermissions(activity, new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
        }, 0);



        //Mostrar en consola todos los mensajes registrados
        MessagesRepository repo = new MessagesRepository(activity);
        repo.getAllMessages().observe(activity, messages -> {
            for(int i=0 ; i<messages.size() ; i++){
                Log.e(">>>"+i,messages.get(i).getId()+":"+messages.get(i).getBody());
            }
        });


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.signinBtn:
                String chatroom = activity.getChatroomET().getText().toString();
                String email = activity.getUsernameET().getText().toString();
                String password = activity.getPasswordET().getText().toString();

                FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener(
                            authResult -> {
                                Intent intent = new Intent(activity, ChatActivity.class);
                                intent.putExtra("chatroom", chatroom);
                                activity.startActivity(intent);
                                activity.finish();
                            }
                    )
                    .addOnFailureListener(e->{
                        Toast.makeText(activity, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                    });




                break;
            case R.id.signupTV:
                Intent i = new Intent(activity, SignupActivity.class);
                activity.startActivity(i);
                break;

            case R.id.continueAsBtn:
                String chatroomToContinue = activity.getChatroomET().getText().toString();

                if(chatroomToContinue.trim().isEmpty()){
                    Toast.makeText(activity, "Debe usar un chatroom para continuar", Toast.LENGTH_LONG).show();
                    return;
                }

                Intent continueIntent = new Intent(activity, ChatActivity.class);
                continueIntent.putExtra("chatroom", chatroomToContinue);
                activity.startActivity(continueIntent);
                activity.finish();

                break;
        }
    }


    //Verificar que haya usuario logeado
    public void onResume() {
        if( FirebaseAuth.getInstance().getUid() == null ){
            activity.getContinueAsBtn().setVisibility(View.GONE);
        }else{
            activity.getContinueAsBtn().setVisibility(View.VISIBLE);
            FirebaseDatabase.getInstance().getReference()
                    .child("users").child(FirebaseAuth.getInstance().getUid())
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            User user = dataSnapshot.getValue(User.class);
                            activity.getContinueAsBtn().setText("Continuar como "+user.getUsername());
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
        }
    }
}
