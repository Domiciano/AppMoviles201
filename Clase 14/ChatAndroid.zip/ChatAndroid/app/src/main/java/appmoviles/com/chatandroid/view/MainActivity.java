package appmoviles.com.chatandroid.view;

import androidx.appcompat.app.AppCompatActivity;
import appmoviles.com.chatandroid.R;
import appmoviles.com.chatandroid.control.MainController;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText chatroomET, usernameET;
    private Button signinBtn;

    private Button continueAsBtn;
    private EditText passwordET;
    private TextView signupTV;

    private MainController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chatroomET = findViewById(R.id.chatroomET);
        usernameET = findViewById(R.id.usernameET);
        signinBtn = findViewById(R.id.signinBtn);
        continueAsBtn = findViewById(R.id.continueAsBtn);
        passwordET = findViewById(R.id.passwordET);
        signupTV = findViewById(R.id.signupTV);

        controller = new MainController(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        controller.onResume();
    }

    public EditText getChatroomET() {
        return chatroomET;
    }

    public EditText getUsernameET() {
        return usernameET;
    }

    public Button getSigninBtn() {
        return signinBtn;
    }

    public Button getContinueAsBtn() {
        return continueAsBtn;
    }

    public EditText getPasswordET() {
        return passwordET;
    }

    public TextView getSignupTV() {
        return signupTV;
    }
}
