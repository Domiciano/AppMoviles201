package appmoviles.com.chatandroid.db;


import androidx.room.Database;
import androidx.room.RoomDatabase;
import appmoviles.com.chatandroid.model.Message;

@Database(entities = {Message.class}, version = 2, exportSchema = false)
public abstract class LocalDatabase  extends RoomDatabase {

    public abstract MessagesDAO daoMessage();

}
