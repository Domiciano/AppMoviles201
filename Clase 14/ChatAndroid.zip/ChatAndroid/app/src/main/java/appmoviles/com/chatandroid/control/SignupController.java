package appmoviles.com.chatandroid.control;

import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import appmoviles.com.chatandroid.R;
import appmoviles.com.chatandroid.model.User;
import appmoviles.com.chatandroid.view.SignupActivity;

public class SignupController implements View.OnClickListener{

    private SignupActivity activity;

    public SignupController(SignupActivity activity){
        this.activity = activity;

        activity.getIhaveuserTV().setOnClickListener(this);
        activity.getSigninBtn().setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.ihaveuserTV:
                activity.finish();
                break;
            case R.id.signinBtn:

                String nombre = activity.getNameET().getText().toString();
                String email = activity.getEmailET().getText().toString();
                String username = activity.getUsernameET().getText().toString();
                String password = activity.getPasswordET().getText().toString();
                String repassword = activity.getRepasswordET().getText().toString();

                if(!password.equals(repassword)){
                    Toast.makeText(activity, "Las contraseñas no coinciden", Toast.LENGTH_LONG).show();
                    return;
                }

                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                    .addOnSuccessListener(authResult -> {
                        //Nos registramos!
                        String uid = FirebaseAuth.getInstance().getUid();
                        User user = new User(uid, nombre, email, username, password);
                        FirebaseDatabase.getInstance().getReference()
                                .child("users").child(user.getId()).setValue(user);
                        activity.finish();
                    })
                    .addOnFailureListener(e->{
                        Toast.makeText(activity, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                    });
                break;
        }
    }
}
