package appmoviles.com.chatandroid.view;

import androidx.appcompat.app.AppCompatActivity;
import appmoviles.com.chatandroid.R;
import appmoviles.com.chatandroid.control.SignupController;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SignupActivity extends AppCompatActivity {

    private EditText nameET;
    private EditText emailET;
    private EditText usernameET;
    private EditText passwordET;
    private EditText repasswordET;
    private TextView ihaveuserTV;
    private Button signinBtn;

    SignupController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        nameET = findViewById(R.id.nameET);
        emailET = findViewById(R.id.emailET);
        usernameET = findViewById(R.id.usernameET);
        passwordET = findViewById(R.id.passwordET);
        repasswordET = findViewById(R.id.repasswordET);
        ihaveuserTV = findViewById(R.id.ihaveuserTV);
        signinBtn = findViewById(R.id.signinBtn);

        controller = new SignupController(this);
    }

    public EditText getNameET() {
        return nameET;
    }

    public EditText getEmailET() {
        return emailET;
    }

    public EditText getUsernameET() {
        return usernameET;
    }

    public EditText getPasswordET() {
        return passwordET;
    }

    public EditText getRepasswordET() {
        return repasswordET;
    }

    public TextView getIhaveuserTV() {
        return ihaveuserTV;
    }

    public Button getSigninBtn() {
        return signinBtn;
    }
}
