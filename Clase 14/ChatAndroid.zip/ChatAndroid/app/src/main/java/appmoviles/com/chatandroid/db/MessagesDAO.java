package appmoviles.com.chatandroid.db;


import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import appmoviles.com.chatandroid.model.Message;

@Dao
public interface MessagesDAO {

    @Insert
    void insertMessage(Message message);

    @Query("SELECT * FROM Message")
    LiveData<List<Message>> getAllMessages();

}
