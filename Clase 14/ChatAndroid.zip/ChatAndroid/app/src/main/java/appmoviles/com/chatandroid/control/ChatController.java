package appmoviles.com.chatandroid.control;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;
import android.view.View;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;

import java.io.File;
import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import appmoviles.com.chatandroid.R;
import appmoviles.com.chatandroid.db.MessagesRepository;
import appmoviles.com.chatandroid.model.FCMMessage;
import appmoviles.com.chatandroid.model.Message;
import appmoviles.com.chatandroid.model.User;
import appmoviles.com.chatandroid.services.FCMService;
import appmoviles.com.chatandroid.util.HTTPSWebUtilDomi;
import appmoviles.com.chatandroid.util.NotificationUtils;
import appmoviles.com.chatandroid.util.UtilDomi;
import appmoviles.com.chatandroid.view.ChatActivity;
import appmoviles.com.chatandroid.view.MainActivity;

import static android.app.Activity.RESULT_OK;

public class ChatController implements View.OnClickListener {

    private static final int GALLERY_CALLBACK = 1;

    private ChatActivity activity;


    private String chatroom;
    private User user;
    private MessagesAdapter adapter;

    private Uri tempUri;

    public ChatController(final ChatActivity activity) {
        this.activity = activity;


        adapter = new MessagesAdapter();
        activity.getMessagesList().setAdapter(adapter);


        chatroom = activity.getIntent().getExtras().getString("chatroom");

        activity.getSendBtn().setOnClickListener(this);
        activity.getGalBtn().setOnClickListener(this);
        activity.getSignoutBtn().setOnClickListener(this);


        FirebaseDatabase.getInstance().getReference()
                .child("users").child(FirebaseAuth.getInstance().getUid())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        user = dataSnapshot.getValue(User.class);
                        adapter.setUserID(user.getId());
                        activity.getUsernameTV().setText(user.getUsername());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


        //Si es una lista
        Query query = FirebaseDatabase.getInstance()
                .getReference()
                .child("chats").child(chatroom).limitToLast(10);
        query.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Message message = dataSnapshot.getValue(Message.class);
                adapter.addMessage(message);

                MessagesRepository repo = new MessagesRepository(activity);
                repo.insertMessage(message);


            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.sendBtn:
                String body = activity.getMessageET().getText().toString();

                String pushId = FirebaseDatabase.getInstance().getReference()
                        .child("chats").child(chatroom).push().getKey();

                Message message = new Message(
                        tempUri == null ? Message.TYPE_TEXT : Message.TYPE_IMAGE,
                        pushId,
                        body,
                        user.getId(),
                        Calendar.getInstance().getTime().getTime());


                FCMMessage fcm = new FCMMessage();
                fcm.setTo("/topics/" + chatroom);
                fcm.setData(message);
                Gson gson = new Gson();
                String json = gson.toJson(fcm);

                new Thread(
                        () -> {
                            HTTPSWebUtilDomi utilDomi = new HTTPSWebUtilDomi();
                            utilDomi.POSTtoFCM(FCMService.API_KEY, json);
                        }
                ).start();


                if (tempUri != null) {
                    FirebaseStorage storage = FirebaseStorage.getInstance();
                    storage.getReference().child("chats").child(message.getId())
                            .putFile(tempUri).addOnCompleteListener(
                            task -> {
                                if (task.isSuccessful()) {
                                    Log.e(">>", "Foto subida con éxito");
                                    FirebaseDatabase.getInstance().getReference()
                                            .child("chats").child(chatroom).child(pushId).setValue(message);
                                }
                            }
                    );
                } else {
                    FirebaseDatabase.getInstance().getReference()
                            .child("chats").child(chatroom).child(pushId).setValue(message);
                }

                activity.hideImage();
                tempUri = null;


                break;

            case R.id.galBtn:

                Intent gal = new Intent(Intent.ACTION_GET_CONTENT);
                gal.setType("image/*");
                activity.startActivityForResult(gal, GALLERY_CALLBACK);

                break;

            case R.id.signoutBtn:
                FirebaseAuth.getInstance().signOut();
                Intent i = new Intent(activity, MainActivity.class);
                activity.startActivity(i);
                activity.finish();
                break;

        }
    }

    public void beforePause() {
        //Suscribirme a un topic
        FirebaseMessaging.getInstance().subscribeToTopic(chatroom).addOnCompleteListener(
                task -> {
                    if (task.isSuccessful()) {
                        Log.e(">>>", "Suscrito!");
                    }
                }
        );
    }

    public void beforeResume() {
        FirebaseMessaging.getInstance().unsubscribeFromTopic(chatroom);
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == GALLERY_CALLBACK && resultCode == RESULT_OK) {
            tempUri = data.getData();
            File file = new File(UtilDomi.getPath(activity, tempUri));
            Bitmap image = BitmapFactory.decodeFile(file.toString());
            activity.getMessageIV().setImageBitmap(image);
            activity.showImage();
        }
    }
}
