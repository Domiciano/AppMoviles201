package appmoviles.com.chatandroid.db;

import android.content.Context;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Room;
import appmoviles.com.chatandroid.model.Message;

public class MessagesRepository {

    private LocalDatabase localDatabase;

    public MessagesRepository(Context context){
        localDatabase = Room.databaseBuilder(
              context,
              LocalDatabase.class,
              "ChatDB"
        ).build();
    }

    public void insertMessage(Message message){
        new Thread(
                ()->{
                    localDatabase.daoMessage().insertMessage(message);
                }
        ).start();
    }

    public LiveData<List<Message>> getAllMessages(){
        return localDatabase.daoMessage().getAllMessages();
    }


}
