package appmoviles.com.pokedex.util;

public class Constants {

    public static final int SEARCH_CALLBACK = 1;
    public static final int CATCH_CALLBACK = 2;
    public static final int GET_MY_POKEMON = 3;

}
