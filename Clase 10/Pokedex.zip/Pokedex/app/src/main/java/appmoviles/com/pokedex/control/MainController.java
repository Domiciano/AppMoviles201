package appmoviles.com.pokedex.control;

import android.util.Log;
import android.view.View;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;

import appmoviles.com.pokedex.R;
import appmoviles.com.pokedex.model.Pokemon;
import appmoviles.com.pokedex.util.Constants;
import appmoviles.com.pokedex.util.HTTPSWebUtilDomi;
import appmoviles.com.pokedex.view.MainActivity;

public class MainController implements View.OnClickListener, HTTPSWebUtilDomi.OnResponseListener {

    private MainActivity activity;
    private HTTPSWebUtilDomi utilDomi;
    private Pokemon pokemon;

    public MainController(MainActivity activity) {
        this.activity = activity;
        this.activity.getSearchBtn().setOnClickListener(this);
        this.activity.getCatchBtn().setOnClickListener(this);
        utilDomi = new HTTPSWebUtilDomi();
        utilDomi.setListener(this);
        loadMyPokemons();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.searchBtn:
                String idOrName = activity.getNameOrIDET().getText().toString();

                new Thread(
                        () -> {
                            utilDomi.GETrequest(Constants.SEARCH_CALLBACK, "https://pokeapi.co/api/v2/pokemon/" + idOrName);
                        }
                ).start();
                break;
            case R.id.catchBtn:

                new Thread(
                        () -> {
                            Gson gson = new Gson();
                            String json = gson.toJson(pokemon);
                            utilDomi.POSTrequest(Constants.CATCH_CALLBACK, "https://pokedex-e7321.firebaseio.com/ash/pokemon.json", json);
                        }
                ).start();

                break;
        }
    }

    @Override
    public void onResponse(int callbackID, String response) {
        switch (callbackID) {
            case Constants.SEARCH_CALLBACK:
                Gson gson = new Gson();

                //{  "Clave1", "Clave2"  }
                pokemon = gson.fromJson(response, new TypeToken<Pokemon>(){}.getType());
                pokemon = gson.fromJson(response, Pokemon.class);
                //En el contexto de un worker thread
                activity.runOnUiThread(
                        () -> {
                            activity.getPokeNameTV().setText(pokemon.getForms()[0].getName());
                            activity.getPokeTypeTV().setText(pokemon.getTypes()[0].getType().getName());

                            activity.getPokeHab1TV().setText(pokemon.getMoves()[0].getMove().getName());
                            activity.getPokeHab2TV().setText(pokemon.getMoves()[1].getMove().getName());
                            activity.getPokeHab3TV().setText(pokemon.getMoves()[2].getMove().getName());
                            activity.getPokeHab4TV().setText(pokemon.getMoves()[3].getMove().getName());

                            activity.getPokeSpeedTV().setText("Speed: " + pokemon.getStats()[0].getBase_stat());
                            activity.getPokeDefenseTV().setText("Defense: " + pokemon.getStats()[3].getBase_stat());
                            activity.getPokeAttacjTV().setText("Attack: " + pokemon.getStats()[4].getBase_stat());
                            activity.getPokeHpTV().setText("Hp: " + pokemon.getStats()[5].getBase_stat());

                            Glide.with(activity).load(
                                    pokemon.getSprites().getFront_default()
                            ).centerCrop().into(activity.getPokeImageIV());
                        }
                );
                break;

            case Constants.CATCH_CALLBACK:
                loadMyPokemons();
                break;

            case Constants.GET_MY_POKEMON:
                Log.e(">>>","response: "+response);
                Gson g = new Gson();
                Type type = new TypeToken< HashMap<String, Pokemon> >(){}.getType();
                HashMap<String, Pokemon> myPoke = g.fromJson(response, type);

                activity.runOnUiThread(
                        ()->{
                            activity.getMyPokemonsTV().setText("");
                            for(String key : myPoke.keySet()){
                                Pokemon pokemon = myPoke.get(key);
                                activity.getMyPokemonsTV().append(pokemon.getForms()[0].getName()+"\n");
                            }
                        }
                );

                break;
        }
    }

    private void loadMyPokemons() {
        new Thread(
                () -> {
                    utilDomi.GETrequest(Constants.GET_MY_POKEMON, "https://pokedex-e7321.firebaseio.com/pokemons.json");
                }
        ).start();
    }
}
