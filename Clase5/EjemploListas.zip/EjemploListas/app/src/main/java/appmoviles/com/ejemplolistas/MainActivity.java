package appmoviles.com.ejemplolistas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private ListView contactsTable;
    private ContactAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contactsTable = findViewById(R.id.contactsTable);
        adapter = new ContactAdapter();
        contactsTable.setAdapter(adapter);

        adapter.addContact(  new Contact("1", "Julián", "21391212")  );
        adapter.addContact(  new Contact("2", "Manuel", "76284122")  );
        adapter.addContact(  new Contact("3", "Mauricio", "8201233")  );
    }
}
