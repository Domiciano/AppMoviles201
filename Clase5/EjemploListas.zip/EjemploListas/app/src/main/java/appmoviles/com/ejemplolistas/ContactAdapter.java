package appmoviles.com.ejemplolistas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ContactAdapter extends BaseAdapter {

    private ArrayList<Contact> contacts;

    public ContactAdapter(){
        contacts = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return contacts.size();
    }

    @Override
    public Object getItem(int i) {
        return contacts.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int pos, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View row = inflater.inflate(R.layout.contact_row, null, false);
        TextView nameRowField = row.findViewById(R.id.nameField);
        TextView phoneRowField = row.findViewById(R.id.phoneRowField);
        nameRowField.setText( contacts.get(pos).getName() );
        phoneRowField.setText( contacts.get(pos).getPhone() );
        return row;
    }

    public void addContact(Contact contact){
        contacts.add(contact);
        notifyDataSetChanged();
    }

}
